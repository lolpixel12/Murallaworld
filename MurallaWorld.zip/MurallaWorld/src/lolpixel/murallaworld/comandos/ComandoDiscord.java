package lolpixel.murallaworld.comandos;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import lolpixel.murallaworld.MurallaWorld;

public class ComandoDiscord implements CommandExecutor{
	
	private MurallaWorld plugin;
	
	public ComandoDiscord(MurallaWorld plugin){
		this.plugin = plugin;
	}

	public boolean onCommand(CommandSender sender, Command comando, String label, String[] args) {
		if(!(sender instanceof Player)){
			Bukkit.getConsoleSender().sendMessage(plugin.nombre+ChatColor.RED+" No puedes ejecutar comandos desde la consola");
			return false;
		}else{
			Player jugador = (Player) sender;
			jugador.sendMessage(ChatColor.LIGHT_PURPLE+"Unete a nuestro discord"+ChatColor.DARK_RED+": https://discord.gg/FkKeFp8");
			
			
			return true;
		}
	}

}
