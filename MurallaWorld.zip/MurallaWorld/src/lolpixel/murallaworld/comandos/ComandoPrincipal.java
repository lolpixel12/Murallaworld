package lolpixel.murallaworld.comandos;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import lolpixel.murallaworld.MurallaWorld;

public class ComandoPrincipal implements CommandExecutor{
	private MurallaWorld plugin;
	
	public ComandoPrincipal(MurallaWorld plugin){
		this.plugin = plugin;
	}

	public boolean onCommand(CommandSender sender, Command comando, String label, String[] args) {
		if(!(sender instanceof Player)){
			Bukkit.getConsoleSender().sendMessage(plugin.nombre+ChatColor.RED+" No puedes ejecutar comandos desde la consola");
			return false;
		}else{
			Player jugador = (Player) sender;
			if(args.length > 0){
				if(args[0].equalsIgnoreCase("version")){
					jugador.sendMessage(plugin.nombre+ChatColor.GOLD+"MurallaWorld: "+ChatColor.GREEN+plugin.version);
					return true;
				}else{
					jugador.sendMessage(plugin.nombre+ChatColor.RED+"Ese comando no existe!");
					return true;
				}
				
			}else{
				jugador.sendMessage(plugin.nombre+ChatColor.RED+"Usa /murallaworld version para ver la version del plugin");
				return true;
			}
		}
	}
}
