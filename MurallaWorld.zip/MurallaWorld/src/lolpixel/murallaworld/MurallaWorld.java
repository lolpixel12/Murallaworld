package lolpixel.murallaworld;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;

import lolpixel.murallaworld.comandos.ComandoDiscord;
import lolpixel.murallaworld.comandos.ComandoPrincipal;

public class MurallaWorld extends JavaPlugin{
	PluginDescriptionFile pdffile = getDescription();
	public String version = pdffile.getVersion();
	public String nombre = ChatColor.DARK_RED+"["+ChatColor.GOLD+pdffile.getName()+ChatColor.DARK_RED+"]"; 				//[MurallaWorld] Rojo Dorado Rojo
	
	public void onEnable(){
		Bukkit.getConsoleSender().sendMessage(""+ChatColor.DARK_RED+"---------------------------------------------------------------");
		Bukkit.getConsoleSender().sendMessage(nombre+ChatColor.GREEN+" MurallaWorld plugin funcionando correctamente"+ChatColor.GOLD+"(version: "+ChatColor.RED+version+ChatColor.GOLD+")");
		Bukkit.getConsoleSender().sendMessage(ChatColor.AQUA+"Plugin creado por: "+ChatColor.DARK_GREEN+"lolpixel");
		Bukkit.getConsoleSender().sendMessage(""+ChatColor.DARK_RED+"---------------------------------------------------------------");
		registrarComandos();
	}
	
	public void onDisable(){
		Bukkit.getConsoleSender().sendMessage(""+ChatColor.DARK_RED+"---------------------------------------------------------------");
		Bukkit.getConsoleSender().sendMessage(nombre+ChatColor.GREEN+" MurallaWorld plugin desactivado correctamente"+ChatColor.GOLD+"(version: "+ChatColor.RED+version+ChatColor.GOLD+")");
		Bukkit.getConsoleSender().sendMessage(ChatColor.AQUA+"Plugin creado por: "+ChatColor.DARK_GREEN+"lolpixel");
		Bukkit.getConsoleSender().sendMessage(""+ChatColor.DARK_RED+"---------------------------------------------------------------");
	}
	
	public void registrarComandos(){
		this.getCommand("discord").setExecutor(new ComandoDiscord(this));
		this.getCommand("murallaworld").setExecutor(new ComandoPrincipal(this));
	}
	
	//MurallaWorld -> Usa /murallaworld version para ver la version del plugin
	//MurallaWorld -> version -> 1.0.2
	//MurallaWolrd ¿-? -> Ese comando no existe 
}
